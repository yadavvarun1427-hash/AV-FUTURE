# AV FUTURE Web Version

## Open on iPhone
1. Download and extract the ZIP.
2. Open `index.html` in a browser-capable file app, or upload it to a free web host.
3. For public access, deploy `index.html` on GitHub Pages, Netlify, Vercel, or any web server.

## Features
- Mobile responsive dashboard
- Readiness percentage calculator
- Fitness screen
- Improvement plan
- No backend required
- 100% free demo

## Disclaimer
The score is an unofficial self-assessment only and does not guarantee official retention, re-employment, or selection.
